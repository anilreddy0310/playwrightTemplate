import { Page } from "playwright";
import { fillLoginData } from "./loginSteps";

export async function loginAndSaveSession(
  page: Page,
  userName: string,
  password: string,
  url: string
): Promise<void> {
  // Navigate to the login page
  await page.goto(url);

  // Wait for the page to load completely
  await page.waitForLoadState("domcontentloaded"); // or "networkidle" if you prefer

  // Clear cookies and local storage before logging in
  const context = page.context();
  await context.clearCookies();
  await context.clearPermissions();

  // Clear local storage and session storage
  await page.evaluate(() => {
    localStorage.clear();
    sessionStorage.clear();
  });

  // Fill in the login data
  await fillLoginData(page, userName, password);

  // Wait for the page to load after login
  await page.waitForLoadState("networkidle");

  // Save the session state
  await context.storageState({ path: `storageState.json` });
}
