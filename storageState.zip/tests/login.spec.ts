import { test, expect } from "./fixtures/custom-fixtures"; // Ensure this is correctly imported
import { loginAndSaveSession } from "../utils/auth-utils";
import settings from "../settings";
import { users } from "./details/userDetails";

test.describe.parallel("Role tests", () => {
  test.beforeAll(async ({ pageObject }) => {
    const adminUser = users.find((user) => user.role === "admin");
    if (!adminUser) {
      throw new Error("Admin user not found");
    }
    if (!settings.baseUrl) {
      throw new Error("Base URL is not found in settings file");
    }

    await loginAndSaveSession(
      pageObject.page,
      adminUser.username,
      adminUser.password,
      settings.baseUrl
    );
    await pageObject.page.context().storageState({ path: `storageState.json` });
  });

  test("should store the admin session", async ({ pageObject }) => {
    await pageObject.page.goto(settings.baseUrl || "");
    await expect(pageObject.page.locator('[aria-label=""] > p')).toHaveText(
      "System Administrator"
    );
  });
});
