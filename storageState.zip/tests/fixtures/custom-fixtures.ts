import { test as base, type Page } from "@playwright/test";

// Generic Page Object class
class BasePage {
  page: Page;

  constructor(page: Page) {
    this.page = page;
  }
  async navigateTo(url: string) {
    await this.page.goto(url);
  }
}

type MyFixtures = {
  pageObject: BasePage;
};

export * from "@playwright/test";
export const test = base.extend<MyFixtures>({
  pageObject: async ({ browser }, use) => {
    const context = await browser.newContext({
      storageState: "storageState.json",
    });
    const pageObject = new BasePage(await context.newPage());
    await use(pageObject);
    await context.close();
  },
});
