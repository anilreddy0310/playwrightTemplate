export const locators = {
  login: {
    username: '[id="username"]',
    password: '[id="password"]',
    submitButton: 'button[type="submit"]',
  },
};
